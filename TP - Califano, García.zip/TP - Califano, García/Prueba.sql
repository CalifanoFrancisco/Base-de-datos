USE examen;

/* 1*/ SELECT              nombre,area,perimetro FROM barrios WHERE nro_comuna     = 3;											-- Bien
/* 2*/ SELECT              nombre,area,perimetro FROM barrios WHERE nro_comuna     > 4 AND nro_comuna<10;							-- Bien
/* 3*/ SELECT                     AREA,PERIMETRO FROM comunas WHERE NRO_COMUNA     = (SELECT comuna  FROM barrios WHERE id=5);		-- Bien
/* 4*/ SELECT                         nro_comuna FROM barrios WHERE nombre      LIKE "V%";									     	-- Bien	
/* 5*/ SELECT                               area FROM barrios WHERE nombre      LIKE "%a%";										-- Bien
/* 6*/ SELECT                          perimetro FROM comunas WHERE nro_comuna     = (SELECT comuna  FROM casos   WHERE id_caso=15);  -- Bien
/* 7*/ SELECT                               area FROM barrios WHERE comuna         = (SELECT comuna  FROM casos   WHERE id_caso=7);   -- Bien
/* 8*/ SELECT                         nro_comuna FROM comunas WHERE nro_comuna    IN (SELECT comuna  FROM casos   WHERE numero_de_caso>6000000 AND numero_de_caso<7000000);
	   SELECT                            id_caso FROM casos   WHERE numero_de_caso >6000000 AND numero_de_caso<7000000;
       SELECT                             nombre FROM barrios WHERE comuna        IN (SELECT comuna  FROM casos   WHERE numero_de_caso>6000000 AND numero_de_caso<7000000);
/* 9*/ SELECT                        genero,edad FROM casos   WHERE barrio         = (SELECT nombre  FROM barrios WHERE id=3); 
/*10*/ SELECT                          id,nombre FROM barrios where id             = (SELECT id_caso FROM casos   WHERE clasificacion = "En investigación");	-- Ninguno se llama en  investigacion
/*11*/ SELECT                          nombre,id FROM barrios WHERE comuna        IN (SELECT comuna  FROM casos   WHERE edad<18);								-- Bien
/*12*/ SELECT id_caso,numero_de_caso,genero,edad FROM casos   WHERE comuna        IN (SELECT comuna  FROM barrios WHERE id!=4);	-- Bien
/*13*/ SELECT                id_caso,genero,edad FROM casos   WHERE comuna        IN (SELECT comuna  FROM barrios WHERE comuna!=13);	

